<?php
// This file is kept for backwards compatibility with older builds.
// Block registration is handled in includes/class-ct-forms.php.
// Intentionally left as a no-op to avoid duplicate block registration notices.
if ( ! defined( 'ABSPATH' ) ) { exit; }
